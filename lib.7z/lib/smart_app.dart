import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'states/app_colors.dart';
import 'states/app_fonts.dart';
import 'states/app_settings.dart';
import 'states/page_state.dart';
import 'states/smart_text.dart';

export 'states/app_colors.dart';
export 'states/app_fonts.dart';
export 'states/app_settings.dart';
export 'states/page_state.dart';
export 'states/smart_text.dart';

class SmartAppPanel {
  late AppColors appColors;
  late AppFonts appFonts;
  late AppSettings appSettings;
  late PageState pageState;

  Future<void> start(
      {bool darkMode = false,
      void Function(bool status)? afterConnectionFunc,
      required List<String> languages,
      required List<Appereance> appereances,
      required Appereance initAppereance,
      AppPages? appPages,
      String initLanguage = "English"}) async {
    appSettings = Get.put(AppSettings(
        afterConnectionFunc: afterConnectionFunc,
        languages: languages,
        initLanguage: initLanguage));
    appFonts = Get.put(AppFonts());
    appColors = Get.put(
        AppColors.withAppereances(appereances, initAppereance: initAppereance));
    if (appPages != null) {
      pageState = Get.put(PageState());
      pageState.initPages(
          pages: appPages.pages, initPageName: appPages.initPage);
    }
  }
}

class AppPages {
  Map<String, Widget> pages = {};

  late String initPage;
}

class SmartPage extends StatelessWidget {
  const SmartPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<PageState>(
      builder: (controller) {
        return controller.page;
      },
    );
  }
}
