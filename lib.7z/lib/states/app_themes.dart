import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../smart_app.dart';
import 'app_settings.dart';

class AppColors extends GetxController {
  late Appereance _currentAppereance;
  List<Appereance> _appereances = [];

  Color get backGroundColor {
    return _currentAppereance.bgColor;
  }

  Color get secondColor {
    return _currentAppereance.secondColor;
  }

  String get name {
    return _currentAppereance.name;
  }

  Color get textColor {
    return _currentAppereance.textColor;
  }

  Color get secondTextColor {
    return _currentAppereance.secondTextColor;
  }

  AppColors.withAppereances(List<Appereance> appereances,
      {required Appereance initAppereance}) {
    _appereances = appereances;
    _currentAppereance = initAppereance;
  }

  void changeAppereance(String name) {
    _currentAppereance =
        _appereances.singleWhere((element) => element.name == name);
   Get.find<AppSettings>().update();
  }
}

class Appereance {
  Color bgColor, secondColor, textColor, secondTextColor;
  String name;

  Appereance(
      {required this.name,
      required this.bgColor,
      required this.secondColor,
      required this.secondTextColor,
      required this.textColor});
}
