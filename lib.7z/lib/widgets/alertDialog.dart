import '/app_states/appSettings.dart';
import '/app_states/colors.dart';
import "package:flutter/material.dart";
import 'package:get/get.dart';
import '../app_states/fonts.dart';

import '../pages/homepage/homepage.dart';

Future<dynamic> myDialog(
    {required Widget child,
    String title = "",
    bool noAction = false,
    bool zeroPadding = false,
    bool barrierDismissible = true,
    Color? bgColor,
    required BuildContext context}) {
  late String hideT;
  if (appSettings.language == "Turkish") {
    hideT = "Kapat";
  }
  if (appSettings.language == "English") {
    hideT = "Close";
  }

  return showDialog(
      context: context,
      barrierDismissible: barrierDismissible, // user must tap button!
      builder: (BuildContext context) {
        Widget? titleWidget = title != ""
            ? Text(
                title,
                style: appFonts.L(isBold: true),
              )
            : null;
        List<Widget>? actions;
        if (noAction == false) {
          actions = [
            TextButton(
              child: Text(hideT, style: appFonts.M(color: appColors.hintColor)),
              onPressed: () {
                Navigator.of(context).pop();
              },
            )
          ];
        }
        return StatefulBuilder(builder: (context, StateSetter setState) {
          return AlertDialog(
            contentPadding: zeroPadding
                ? EdgeInsets.zero
                : const EdgeInsets.fromLTRB(24.0, 20.0, 24.0, 24.0),
            title: titleWidget,
            backgroundColor: bgColor == null ? appColors.extraPage : bgColor,
            content: SingleChildScrollView(
              child: ListBody(children: <Widget>[child]),
            ),
            actions: actions,
          );
        });
      });
}
